/// بيانات إضافية لرأس الاختبار الورقي.
/// تُمرَّر إلى ExamPdfService مع Exam و Questions.
class ExamPdfMetadata {
  final String schoolName;
  final String? educationAuthority;
  final String? schoolLogoPath;
  final String academicYear;

  final String subjectName;
  final String className;
  final String? sectionName;

  /// نص الدولة (مثال: "الجمهورية اليمنية")
  final String country;

  /// نص الوزارة (مثال: "وزارة التربية والتعليم")
  final String ministry;

  /// هل نعرض البسملة في الأعلى
  final bool showBasmala;

  const ExamPdfMetadata({
    required this.schoolName,
    this.educationAuthority,
    this.schoolLogoPath,
    this.academicYear = '2024-2025',
    required this.subjectName,
    required this.className,
    this.sectionName,
    this.country = 'الجمهورية اليمنية',
    this.ministry = 'وزارة التربية والتعليم',
    this.showBasmala = true,
  });
}
