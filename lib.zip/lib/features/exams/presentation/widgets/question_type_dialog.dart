// lib/features/exams/presentation/widgets/question_type_dialog.dart
import 'package:flutter/material.dart';

import '../../../../core/theme/app_spacing.dart';
import '../../domain/entities/exam.dart';

class QuestionTypeDialog extends StatelessWidget {
  final String examId;
  final String? parentId;
  
  const QuestionTypeDialog({super.key, required this.examId, this.parentId});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'اختر نوع السؤال',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: AppSpacing.lg),
              Wrap(
                spacing: AppSpacing.md,
                runSpacing: AppSpacing.md,
                children: QuestionType.values
                    .where((t) => t != QuestionType.groupHeader)
                    .map((type) {
                  return _QuestionTypeButton(
                    type: type,
                    onTap: () {
                      Navigator.pop(context, type);
                    },
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class _QuestionTypeButton extends StatelessWidget {
  final QuestionType type;
  final VoidCallback onTap;
  
  const _QuestionTypeButton({
    required this.type,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 140,
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.3),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _getIconForType(type),
              size: 32,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              type.label,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.labelMedium,
            ),
          ],
        ),
      ),
    );
  }
  
  IconData _getIconForType(QuestionType type) {
    switch (type) {
      case QuestionType.multipleChoice:
        return Icons.list_alt;
      case QuestionType.trueFalse:
        return Icons.check_circle_outline;
      case QuestionType.shortAnswer:
        return Icons.short_text;
      case QuestionType.essay:
        return Icons.article;
      case QuestionType.fillBlank:
        return Icons.space_bar;
      case QuestionType.matching:
        return Icons.compare_arrows;
      case QuestionType.ordering:
        return Icons.format_list_numbered;
      case QuestionType.multipleAnswers:
        return Icons.checklist;
      case QuestionType.image:
        return Icons.image;
      case QuestionType.table:
        return Icons.table_chart;
      case QuestionType.math:
        return Icons.functions;
      case QuestionType.groupHeader:
        return Icons.title;
    }
  }
}