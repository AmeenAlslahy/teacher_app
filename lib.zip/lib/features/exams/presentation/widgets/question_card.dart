// lib/features/exams/presentation/widgets/question_card.dart
import 'package:flutter/material.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../domain/entities/exam.dart';

class QuestionCard extends StatelessWidget {
  final Question question;
  final int index;
  final VoidCallback onEdit;
  final VoidCallback onDuplicate;
  final VoidCallback onDelete;
  final VoidCallback? onMoveUp;
  final VoidCallback? onMoveDown;
  final bool isNew;  // ✅ جديد
  
  const QuestionCard({
    super.key,
    required this.question,
    required this.index,
    required this.onEdit,
    required this.onDuplicate,
    required this.onDelete,
    this.onMoveUp,
    this.onMoveDown,
    this.isNew = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: isNew
          ? RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.green.shade400, width: 2),
            )
          : null,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '${index + 1}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        question.type.label,
                        style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        '${question.marks} درجة',
                        style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.edit),
                  tooltip: 'تعديل',
                  onPressed: onEdit,
                ),
                IconButton(
                  icon: const Icon(Icons.copy),
                  tooltip: 'نسخ',
                  onPressed: onDuplicate,
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  tooltip: 'حذف',
                  onPressed: onDelete,
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              question.content,
              style: Theme.of(context).textTheme.bodyMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            if (question.options.isNotEmpty) ...[
              const SizedBox(height: AppSpacing.sm),
              ...question.options.map((option) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  children: [
                    Icon(
                      option.isCorrect
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      size: 16,
                      color: option.isCorrect
                          ? Colors.green
                          : Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      option.content, // Using content instead of text to match QuestionOption
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              )),
            ],
            if (onMoveUp != null || onMoveDown != null) ...[
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: [
                  if (onMoveUp != null)
                    IconButton(
                      icon: const Icon(Icons.arrow_upward),
                      tooltip: 'تحريك لأعلى',
                      onPressed: onMoveUp,
                    ),
                  if (onMoveDown != null)
                    IconButton(
                      icon: const Icon(Icons.arrow_downward),
                      tooltip: 'تحريك لأسفل',
                      onPressed: onMoveDown,
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}