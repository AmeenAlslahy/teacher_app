// lib/features/exams/presentation/pages/exam_editor_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'dart:async';

import '../../../../core/widgets/app_snackbar.dart';
import '../../../../core/widgets/app_loading.dart';
import '../../../../core/di/injection.dart';
import '../../../context/providers/context_provider.dart';
import '../../providers/exam_provider.dart';

import '../widgets/exam_settings_step.dart';
import '../widgets/exam_questions_step.dart';
import '../widgets/exam_review_step.dart';

class ExamEditorPage extends StatefulWidget {
  final String? examId;
  
  const ExamEditorPage({super.key, this.examId});

  @override
  State<ExamEditorPage> createState() => _ExamEditorPageState();
}

class _ExamEditorPageState extends State<ExamEditorPage> {
  late final ExamProvider _provider;
  bool _isInitialized = false;
  Timer? _autoSaveTimer;

  @override
  void initState() {
    super.initState();
    _provider = getIt<ExamProvider>();
    _initializeExam();
  }

  void _initializeExam() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      _provider.reset();

      final contextProvider = context.read<ContextProvider>();

      if (widget.examId != null) {
        await _provider.loadExam(widget.examId!);
      } else {
        if (!mounted) return;
        // ✅ نُمرر السياق الحالي أولًا
        _provider.setContext(
          schoolId: contextProvider.schoolId ?? '',
          classId: contextProvider.classId ?? '',
          sectionId: contextProvider.sectionId,
          subjectId: contextProvider.subjectId ?? '',
          subjectName: contextProvider.subjectName,
        );
        _provider.createNewExam();
      }

      if (mounted) {
        setState(() {
          _isInitialized = true;
        });
        _startAutoSave();
      }
    });
  }

  void _startAutoSave() {
    _autoSaveTimer = Timer.periodic(const Duration(seconds: 30), (timer) async {
      if (mounted && _provider.saveStatus == 'مسودة غير محفوظة' && !_provider.isSaving) {
        final success = await _provider.saveExam();
        if (success && mounted) {
          setState(() {});
        }
      }
    });
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return const Scaffold(
        body: AppLoading(message: 'جاري تجهيز محرر الاختبار...'),
      );
    }

    return ChangeNotifierProvider.value(
      value: _provider,
      child: const _ExamEditorStepper(),
    );
  }
}

class _ExamEditorStepper extends StatefulWidget {
  const _ExamEditorStepper();

  @override
  State<_ExamEditorStepper> createState() => _ExamEditorStepperState();
}

class _ExamEditorStepperState extends State<_ExamEditorStepper> {
  int _currentStep = 0;

  void _nextStep() {
    if (_currentStep == 0) {
      final provider = context.read<ExamProvider>();
      final exam = provider.currentExam;

      // 1. تحقق محلي سريع (بلا DB)
      if (exam == null) return;

      if (exam.title.trim().isEmpty) {
        AppSnackbar.show(
          context,
          message: 'يرجى إدخال عنوان الاختبار قبل المتابعة',
          type: SnackbarType.warning,
        );
        return;
      }

      if (exam.schoolId.isEmpty ||
          exam.classId.isEmpty ||
          exam.subjectId.isEmpty) {
        AppSnackbar.show(
          context,
          message: 'السياق الدراسي غير مكتمل. اختر المدرسة والصف والمادة',
          type: SnackbarType.error,
        );
        return;
      }

      // 2. انتقال فوري
      setState(() => _currentStep += 1);

      // 3. حفظ في الخلفية — بلا انتظار
      provider.saveExam().then((success) {
        if (!success && mounted) {
          AppSnackbar.show(
            context,
            message: provider.error ?? 'فشل في حفظ الاختبار',
            type: SnackbarType.error,
          );
        }
      });
      return;
    }

    if (_currentStep < 2) {
      setState(() => _currentStep += 1);
    }
  }

  void _previousStep() {
    if (_currentStep > 0) {
      setState(() => _currentStep -= 1);
    }
  }

  Future<void> _saveAndExit() async {
    final provider = context.read<ExamProvider>();
    final errors = await provider.validateExam();
    
    if (errors.isNotEmpty) {
      if (!mounted) return;
      AppSnackbar.show(
        context,
        message: 'لا يمكن الحفظ: ${errors.first}',
        type: SnackbarType.error,
      );
      return;
    }
    
    final success = await provider.saveExam();
    if (!mounted) return;

    if (success) {
      context.goNamed('exams');
    } else {
      AppSnackbar.show(
        context,
        message: provider.error ?? 'فشل في حفظ الاختبار',
        type: SnackbarType.error,
      );
    }
  }

  Widget _buildSaveIndicator(BuildContext context, ExamProvider provider) {
    final IconData icon;
    final Color color;
    final String text;

    if (provider.isSaving) {
      icon = Icons.sync;
      color = Theme.of(context).colorScheme.primary;
      text = 'جاري الحفظ...';
    } else if (provider.saveStatus.contains('✓')) {
      icon = Icons.cloud_done;
      color = Colors.green;
      text = 'محفوظ';
    } else if (provider.saveStatus.contains('فشل')) {
      icon = Icons.error_outline;
      color = Theme.of(context).colorScheme.error;
      text = 'فشل الحفظ';
    } else if (provider.saveStatus.isNotEmpty) {
      icon = Icons.edit_note;
      color = Colors.orange;
      text = 'مسودة غير محفوظة';
    } else {
      icon = Icons.check_circle_outline;
      color = Theme.of(context).colorScheme.onSurfaceVariant;
      text = 'محفوظ';
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: color),
        const SizedBox(width: 4),
        Text(
          text,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontSize: 11,
                color: color,
                fontWeight: FontWeight.w500,
              ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ExamProvider>();
    final exam = provider.currentExam;

    if (provider.isLoading && exam == null) {
      return const Scaffold(body: AppLoading(message: 'جاري تحميل الاختبار...'));
    }

    if (exam == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('الاختبار غير موجود')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              exam.title.isNotEmpty ? exam.title : 'اختبار جديد',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            _buildSaveIndicator(context, provider),
          ],
        ),
        actions: [
          IconButton(
            icon: provider.isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
            tooltip: 'حفظ يدوي',
            onPressed: provider.isSaving ? null : () => provider.saveExam(),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Stepper(
        type: StepperType.horizontal,
        currentStep: _currentStep,
        elevation: 0,
        controlsBuilder: (context, details) => const SizedBox.shrink(), // We use custom buttons in the steps
        onStepTapped: (index) {
          setState(() => _currentStep = index);
        },
        steps: [
          Step(
            title: const Text('الإعدادات'),
            isActive: _currentStep >= 0,
            state: _currentStep > 0 ? StepState.complete : StepState.indexed,
            content: ExamSettingsStep(
              onNext: _nextStep,
            ),
          ),
          Step(
            title: const Text('الأسئلة'),
            isActive: _currentStep >= 1,
            state: _currentStep > 1 ? StepState.complete : StepState.indexed,
            content: ExamQuestionsStep(
              onNext: _nextStep,
              onBack: _previousStep,
            ),
          ),
          Step(
            title: const Text('المراجعة'),
            isActive: _currentStep >= 2,
            content: ExamReviewStep(
              onBack: _previousStep,
              onSave: _saveAndExit,
            ),
          ),
        ],
      ),
    );
  }
}