// lib/features/exams/presentation/pages/question_editor_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_math_fork/flutter_math.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/app_dropdown.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../../../core/widgets/app_loading.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/di/injection.dart';
import '../../domain/entities/exam.dart';
import '../../domain/entities/question_content.dart';

import '../../providers/question_editor_provider.dart';
import '../widgets/math_equation_editor.dart';
import '../widgets/chemistry_editor.dart';

class QuestionEditorPage extends StatelessWidget {
  final QuestionType type;
  final String? questionId;
  final String examId;
  final String? parentId;
  
  const QuestionEditorPage({
    super.key,
    required this.type,
    this.questionId,
    required this.examId,
    this.parentId,
  });

  @override
  Widget build(BuildContext context) {
    final params = QuestionEditorParams(
      type: type,
      questionId: questionId,
      examId: examId,
      parentId: parentId,
    );
    
    return ChangeNotifierProvider(
      create: (context) => getIt<QuestionEditorProvider>(param1: params),
      child: const _QuestionEditorView(),
    );
  }
}

class _QuestionEditorView extends StatelessWidget {
  const _QuestionEditorView();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    
    if (provider.isLoading) {
      return const Scaffold(
        body: AppLoading(message: 'جاري تحميل السؤال...'),
      );
    }
    
    return Scaffold(
      appBar: AppBar(
        title: Text('${provider.type.label} - محرر السؤال'),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth > 800) {
            // Split screen for Tablets/Desktop
            return Row(
              children: [
                Expanded(
                  flex: 1,
                  child: _buildEditorForm(context),
                ),
                const VerticalDivider(width: 1),
                Expanded(
                  flex: 1,
                  child: _buildPreviewPane(context),
                ),
              ],
            );
          } else {
            // Mobile: Tabs
            return DefaultTabController(
              length: 2,
              child: Column(
                children: [
                  const TabBar(
                    tabs: [
                      Tab(text: 'التحرير', icon: Icon(Icons.edit)),
                      Tab(text: 'المعاينة', icon: Icon(Icons.visibility)),
                    ],
                  ),
                  Expanded(
                    child: TabBarView(
                      children: [
                        _buildEditorForm(context),
                        _buildPreviewPane(context),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
      bottomNavigationBar: _buildBottomBar(context),
    );
  }
  
  Widget _buildEditorForm(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    return ListView(
      padding: const EdgeInsets.all(AppSpacing.md),
      children: [
        _buildQuestionContent(context),
        const SizedBox(height: AppSpacing.lg),
        if (provider.hasOptions)
          _buildOptionsSection(context),
        const SizedBox(height: AppSpacing.lg),
        _buildSettingsSection(context),
        const SizedBox(height: AppSpacing.lg),
        _buildAnswerSection(context),
      ],
    );
  }

  Widget _buildPreviewPane(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    return Container(
      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
      child: ListView(
        padding: const EdgeInsets.all(AppSpacing.xl),
        children: [
          AppCard(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'معاينة السؤال',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.grey),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${provider.marksController.text} درجات',
                        style: TextStyle(color: Theme.of(context).colorScheme.onPrimaryContainer),
                      ),
                    ),
                  ],
                ),
                const Divider(),
                const SizedBox(height: AppSpacing.md),
                Text(
                  provider.contentController.text.isEmpty ? 'نص السؤال سيظهر هنا...' : provider.contentController.text,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: AppSpacing.md),
                if (provider.contentBlocks.isNotEmpty)
                  ...provider.contentBlocks.map((block) => Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: block.type == ContentBlockType.math || block.type == ContentBlockType.physics
                      ? Math.tex(block.content, textStyle: const TextStyle(fontSize: 18))
                      : Text(block.content),
                  )),
                const SizedBox(height: AppSpacing.lg),
                if (provider.hasOptions)
                  ...provider.optionControllers.asMap().entries.map((entry) {
                    final text = entry.value.text;
                    final isCorrect = provider.optionCorrectness[entry.key];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Row(
                        children: [
                          Icon(
                            provider.type == QuestionType.multipleChoice ? Icons.radio_button_unchecked : Icons.check_box_outline_blank,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              text.isEmpty ? 'الخيار ${entry.key + 1}' : text,
                              style: TextStyle(
                                fontWeight: isCorrect ? FontWeight.bold : FontWeight.normal,
                                color: isCorrect ? Colors.green : null,
                              ),
                            ),
                          ),
                          if (isCorrect)
                            const Icon(Icons.check, color: Colors.green, size: 16),
                        ],
                      ),
                    );
                  }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================
  // محتوى السؤال
  // ============================
  
  Widget _buildQuestionContent(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    
    return AppCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'محتوى السؤال',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          
          AppTextField(
            label: 'نص السؤال',
            controller: provider.contentController,
            isRequired: true,
            isMultiline: true,
            maxLines: 5,
            hint: 'اكتب السؤال هنا...\nيمكنك إدراج معادلات من الأزرار أعلاه',
          ),
          
          const SizedBox(height: AppSpacing.md),

          // ✅ أدوات متقدمة - مخفية افتراضيًا
          Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(top: AppSpacing.sm),
              initiallyExpanded: provider.contentBlocks.isNotEmpty,
              leading: Icon(
                Icons.auto_awesome,
                size: 20,
                color: Theme.of(context).colorScheme.primary,
              ),
              title: Text(
                'أدوات متقدمة',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              subtitle: Text(
                'معادلات رياضية، كيميائية، فيزيائية',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
              children: [
                Wrap(
                  spacing: AppSpacing.sm,
                  runSpacing: AppSpacing.sm,
                  children: [
                    _buildQuickInsertButton(
                      context,
                      'رياضيات',
                      Icons.functions,
                      () => _showMathEditor(context),
                    ),
                    _buildQuickInsertButton(
                      context,
                      'كيمياء',
                      Icons.science,
                      () => _showChemistryEditor(context),
                    ),
                    _buildQuickInsertButton(
                      context,
                      'فيزياء',
                      Icons.bolt,
                      () => _showPhysicsEditor(context),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          if (provider.contentBlocks.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.lg),
            Text(
              'المحتوى المضاف:',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: AppSpacing.sm),
            ...provider.contentBlocks.map((block) => _buildContentBlock(context, block)),
          ],
        ],
      ),
    );
  }
  
  Widget _buildQuickInsertButton(
    BuildContext context, 
    String label, 
    IconData icon, 
    VoidCallback onPressed,
  ) {
    return TextButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: TextButton.styleFrom(
        backgroundColor: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
  
  Widget _buildContentBlock(BuildContext context, ContentBlock block) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: ListTile(
        leading: Icon(_getBlockIcon(block.type)),
        title: block.type == ContentBlockType.math ||
                block.type == ContentBlockType.physics
            ? SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Math.tex(block.content, textStyle: const TextStyle(fontSize: 18)),
              )
            : Text(block.content),
        subtitle: Text(block.type.label),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline),
          onPressed: () {
            showDialog(
              context: context,
              builder: (dialogContext) => AlertDialog(
                title: const Text('حذف المحتوى'),
                content: const Text('هل أنت متأكد من حذف هذا المحتوى؟'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إلغاء'),
                  ),
                  FilledButton(
                    onPressed: () {
                      Navigator.pop(dialogContext);
                      context.read<QuestionEditorProvider>().removeContentBlock(block.id);
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.error,
                    ),
                    child: const Text('حذف'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
  
  IconData _getBlockIcon(ContentBlockType type) {
    switch (type) {
      case ContentBlockType.text: return Icons.text_fields;
      case ContentBlockType.math: return Icons.functions;
      case ContentBlockType.physics: return Icons.bolt;
      case ContentBlockType.chemistry: return Icons.science;
      case ContentBlockType.image: return Icons.image;
      case ContentBlockType.table: return Icons.table_chart;
      default: return Icons.text_fields;
    }
  }
  
  // ============================
  // الخيارات
  // ============================
  
  Widget _buildOptionsSection(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    
    return AppCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            provider.type == QuestionType.multipleChoice
                ? 'الخيارات (اختر إجابة واحدة صحيحة)'
                : 'الخيارات (يمكن اختيار أكثر من إجابة)',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          ...provider.optionControllers.asMap().entries.map((entry) {
            final index = entry.key;
            final controller = entry.value;
            
            return Padding(
              padding: const EdgeInsets.only(bottom: AppSpacing.md),
              child: Row(
                children: [
                  Expanded(
                    child: AppTextField(
                      label: 'الخيار ${index + 1}',
                      controller: controller,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  IconButton(
                    icon: Icon(
                      provider.optionCorrectness[index]
                          ? Icons.check_circle
                          : Icons.radio_button_unchecked,
                      color: provider.optionCorrectness[index]
                          ? Colors.green
                          : Colors.grey,
                    ),
                    tooltip: 'تحديد كإجابة صحيحة',
                    onPressed: () => provider.toggleOptionCorrect(index),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
  
  // ============================
  // الإعدادات
  // ============================
  
  Widget _buildSettingsSection(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    
    return AppCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'إعدادات السؤال',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          AppTextField(
            label: 'الدرجة',
            controller: provider.marksController,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: AppSpacing.md),
          AppDropdown<Difficulty>(
            label: 'مستوى الصعوبة',
            value: provider.difficulty,
            items: Difficulty.values.map((d) {
              return DropdownMenuItem(
                value: d,
                child: Text(d.label),
              );
            }).toList(),
            onChanged: (value) {
              if (value != null) provider.setDifficulty(value);
            },
          ),
        ],
      ),
    );
  }
  
  // ============================
  // الإجابة والشرح
  // ============================
  
  Widget _buildAnswerSection(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    
    if (provider.hasOptions) return const SizedBox.shrink();
    
    return AppCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'الإجابة والشرح',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          if (provider.type == QuestionType.trueFalse)
            AppDropdown<String>(
              label: 'الإجابة الصحيحة',
              value: provider.correctAnswer,
              items: const [
                DropdownMenuItem(value: 'true', child: Text('صح')),
                DropdownMenuItem(value: 'false', child: Text('خطأ')),
              ],
              onChanged: (value) {
                provider.setCorrectAnswer(value);
              },
            )
          else
            AppTextField(
              label: 'الإجابة الصحيحة',
              isMultiline: true,
              maxLines: 2,
              onChanged: (value) {
                provider.setCorrectAnswer(value);
              },
            ),
          const SizedBox(height: AppSpacing.md),
          AppTextField(
            label: 'شرح الإجابة (اختياري)',
            controller: provider.explanationController,
            isMultiline: true,
            maxLines: 3,
          ),
        ],
      ),
    );
  }
  
  // ============================
  // Bottom Bar
  // ============================
  
  Widget _buildBottomBar(BuildContext context) {
    final provider = context.watch<QuestionEditorProvider>();
    
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: AppButton(
                text: 'حفظ وإغلاق',
                type: AppButtonType.outline,
                icon: Icons.save,
                isLoading: provider.isSaving,
                onPressed: provider.isSaving ? null : () => _saveQuestion(context, addNext: false),
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              flex: 2,
              child: AppButton(
                text: 'حفظ وإضافة جديد',
                type: AppButtonType.primary,
                icon: Icons.add_task,
                isLoading: provider.isSaving,
                onPressed: provider.isSaving ? null : () => _saveQuestion(context, addNext: true),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  // ============================
  // المحررات
  // ============================
  
  void _showMathEditor(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => MathEquationEditor(
        onSave: (latex) {
          final provider = context.read<QuestionEditorProvider>();
          provider.insertInlineBlock(ContentBlockType.math, latex);
        },
      ),
    );
  }
  
  void _showChemistryEditor(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => ChemistryEditor(
        onSave: (formula) {
          final provider = context.read<QuestionEditorProvider>();
          provider.insertInlineBlock(ContentBlockType.chemistry, formula);
        },
      ),
    );
  }
  
  void _showPhysicsEditor(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => MathEquationEditor(
        onSave: (latex) {
          final provider = context.read<QuestionEditorProvider>();
          provider.insertInlineBlock(ContentBlockType.physics, latex);
        },
      ),
    );
  }
  
  // ============================
  // حفظ السؤال
  // ============================
  
  Future<void> _saveQuestion(BuildContext context, {bool addNext = false}) async {
    final provider = context.read<QuestionEditorProvider>();
    final success = await provider.saveQuestion();
    
    if (!context.mounted) return;
    
    if (success) {
      AppSnackbar.show(
        context,
        message: 'تم حفظ السؤال بنجاح',
        type: SnackbarType.success,
      );
      
      if (addNext) {
        // Reset the provider state for a new question
        provider.resetForm();
      } else {
        Navigator.pop(context);
      }
    } else {
      AppSnackbar.show(
        context,
        message: provider.error ?? 'فشل في حفظ السؤال',
        type: SnackbarType.error,
      );
    }
  }
}