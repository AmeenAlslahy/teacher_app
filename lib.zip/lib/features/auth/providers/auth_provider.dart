import 'package:flutter/material.dart';
class AuthProvider extends ChangeNotifier {
AuthProvider(db);
}